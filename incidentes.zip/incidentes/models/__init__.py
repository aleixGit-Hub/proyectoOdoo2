# -*- coding: utf-8 -*-

from . import alumno
from . import asignatura
from . import grupo
from . import parte
from . import profesor